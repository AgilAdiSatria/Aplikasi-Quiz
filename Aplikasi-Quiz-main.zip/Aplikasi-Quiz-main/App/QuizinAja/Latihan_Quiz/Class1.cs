﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Latihan_Quiz
{
    internal class Class1
    {
        private static string Uname;
        public static string uname
        {
            get { return Uname; }
            set { Uname = value; }
        }
        private static string UserID;
        public static string userID
        {
            get { return UserID; }
            set { UserID = value; }
        }
        private static string QuizID;
        public static string quizID
        {
            get { return QuizID; }
            set { QuizID = value; }
        }
        private static string ID;
        public static string id
        {
            get { return ID; }
            set { ID = value; }
        }
       

    }
}
